# Which variable blocks are implemented?

Block					  	  | Implementation Status
--------------------	        | ----------------------
set [] to 0                     | Done
change [] by 1	                | Done
show variable []                | Stub function in place
hide variable []                | Stub function in place
script variables (a)            | Done
                                | 
list []                         | 
[] in front of []               | 
item 1 of []                    | 
all but first of []             | 
                                | 
length of []                    | 
[] contains thing               | 
                                | 
add thing to []                 | 
delete 1 of []                  | 
insert thing at 1 of []         | 
replace item 1 of [] with thing |
                                | 
