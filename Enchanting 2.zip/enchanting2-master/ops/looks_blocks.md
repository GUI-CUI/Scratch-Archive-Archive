# Which looks blocks are implemented?

Block						| Implementation Status
--------------------		| ----------------------
switch to costume           | Done                              
next costume                | Done                          
costume #                   | Done                              
                            | 
say hello for 2 secs        | Works (needs improved layout)
say hello                   | As above
think Hmm... for 2 secs     | As above
think Hmm...                | As above
                            | 
change [ghost] effect by 25 | 
set [ghost] effect to 0     |   
clear graphic effects       |
                            | 
change size by 10           | Done
set size to 100%            | Done
size                        | Done
                            | 
show                        | 
hide                        | 
                            | 
go to front                 | 
go back 1 layers            | 
                            | 
 