# Which motion blocks are implemented?

Block						| Implementation Status
--------------------		| ----------------------
move 10 steps 				| Done
turn <- 15 degrees			| Done (but no bounds checking)
turn -> 15 degrees			| Done (but no bounds checking)
                            |
point in direction 90		| Done
point towards [ ]			| 
                            |
go to x: 0 y: 0				| Done
go to [ ]					| 
glide 1 secs to x: 0 y: 0	| 
                            |
change x by 10				| Done
set x to 0					| Done
change y by 10				| Done
set y to 0					| Done
                            |
if on edge, bounce			| 
                            |
x position					| Done
y position					| Done
direction					| Done

