# Which operator blocks are implemented?

Block						| Implementation Status
--------------------		| ----------------------
() + ()                     | Done
() - ()                     | Done
() x ()                     | Done
() / ()                     | Done
                            | 
() mod ()                   | 
round ()                    | 
[sqrt] of 10                | 
pick random 1 to 10         | 
                            | 
[] < []                     | Done
[] = []                     | Done
[] > []                     | Done
                            | 
<> and <>                   | Done
<> or <>                    | Done
not <>                      | Done
                            | 
true                        | Done
false                       | Done
                            | 
join hello world            | 
split hello world by        | 
letter 1 or world           | 
length of world             | 
                            | 
unicode of a                | 
unicode 65 as letter        | 
                            | 
if 5 a number?              | 
is [] identical to []       | 
                            | 
javascript function         | (we should add 'python function')!
