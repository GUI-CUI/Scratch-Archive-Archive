# Which control blocks are implemented?

Block						| Implementation Status
--------------------		| ----------------------
When green flag clicked     | Done
When space key pressed      | Works (not all keys understood)
When I am clicked           |
When I receive [ ]          | Done
                            |
broadcast [ ]               | Done
broadcast [ ] and wait      |
(message)                   |
                            |                                   
warp                        |
                            |
wait 1 secs                 | Done
wait until < >              |
                            |
forever                     | Done
repeat 10                   | Done
repeat until < >            |                                   
                            |                                   
if <>                       | Done                              
if <> else                  | Done                              
                            |                                   
report [ ]                  | Done                              
                            |                                   
stop [all]                  |                                   
stop [all but this script]  |                                   
                            |                                   
run                         |                                   
launch                      |                                   
call                        |                                   
                            |                                   
run w/continuation          |                                  
call w/continuation         |                                
                            |                                   
when I start as a clone     |                                   
create a clone if [ ]       |                                   
delete this clone           |
                            |                                   
pause all                   |

