## Eureka
This is a modification of [the Scratch Flash Player/Editor](https://github.com/LLK/scratch-flash).

## Why use Eureka?
Eureka plans to add several highly-requested but still unimplemented features to Scratch.
With Eureka, you can use several new features to make your projects even better!

## Why not fork it?
This way I can make pull requests to Scratch Flash without having to worry about my mod's files getting in the way.
